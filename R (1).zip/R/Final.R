#importation des données 
mydata<-read.csv('data.csv')

#on va verifier s'il ya pas de valeurs manquante
is.null(mydata)

##erifications des valeurs dupliqueés
sum_value<-sum(duplicated(mydata))
sum_value

#voir le pourcentage pour le test
size_test <- as.data.frame(table(mydata$test_preparation_course))
size_test
size_test$percent <- size_test$Freq / sum(size_test$Freq) * 100
ex_test<-ggplot(size_test, aes(x="", y=Freq, fill=Var1)) +
  geom_bar(stat="identity", width=1, color="white") +
  geom_text(aes(label=paste0(round(percent),"%")), position=position_stack(vjust=0.5)) +
  coord_polar("y", start=0) +
  theme_void() +
  scale_fill_manual(values=c("orange","pink")) +
  ggtitle("Preparation du test")
ex_test + theme(plot.title = element_text(hjust = 0.5))

#voir le pourcentage pour  race_ethinicity
size_race <- as.data.frame(table(mydata$race_ethnicity))
size_race
size_race$percent <- size_race$Freq / sum(size_race$Freq) * 100
ex_race<-ggplot(size_race, aes(x="", y=Freq, fill=Var1)) +
  geom_bar(stat="identity", width=1, color="white") +
  geom_text(aes(label=paste0(round(percent),"%")), position=position_stack(vjust=0.5)) +
  coord_polar("y", start=0) +
  theme_void() +
  scale_fill_manual(values=c("yellow","pink","blue", "green","orange")) +
  ggtitle("Race/Ethnicity")
ex_race + theme(plot.title = element_text(hjust = 0.5))

#voir le pourcentage pour lunch
size_lunch <- as.data.frame(table(mydata$lunch))
size_lunch
size_lunch$percent <- size_lunch$Freq / sum(size_lunch$Freq) * 100
ex_lunch<-ggplot(size_lunch, aes(x="", y=Freq, fill=Var1)) +
  geom_bar(stat="identity", width=1, color="white") +
  geom_text(aes(label=paste0(round(percent),"%")), position=position_stack(vjust=0.5)) +
  coord_polar("y", start=0) +
  theme_void() +
  scale_fill_manual(values=c("yellow","pink")) +
  ggtitle("lunch")
ex_lunch + theme(plot.title = element_text(hjust = 0.5))

#voir le pourcentage de parental level of education
size_parental <- as.data.frame(table(mydata$parental_level_of_education))
size_parental
size_parental$percent <- size_parental$Freq / sum(size_parental$Freq) * 100
ex_parental_<-ggplot(size_parental, aes(x="", y=Freq, fill=Var1)) +
  geom_bar(stat="identity", width=1, color="white") +
  geom_text(aes(label=paste0(round(percent),"%")), position=position_stack(vjust=0.5)) +
  coord_polar("y", start=0) +
  theme_void() +
  scale_fill_manual(values=c("yellow","pink","blue", "green","red","orange")) +
  ggtitle("parental level of_education")
ex_parental_ + theme(plot.title = element_text(hjust = 0.5))

#voir le pourcentage gender
sizes <- as.data.frame(table(mydata$gender))
sizes$percent <- sizes$Freq / sum(sizes$Freq) * 100
ex_gender<-ggplot(sizes, aes(x="", y=Freq, fill=Var1)) +
  geom_bar(stat="identity", width=1, color="white") +
  geom_text(aes(label=paste0(round(percent),"%")), position=position_stack(vjust=0.5)) +
  coord_polar("y", start=0) +
  theme_void() +
  scale_fill_manual(values=c("pink", "blue")) +
  ggtitle("Gender")
ex_gender + theme(plot.title = element_text(hjust = 0.5))

#creation de deux variables total et moyenne
mydata['Total'] = mydata$math_score + mydata$reading_score + mydata$writing_score
mydata['Average'] = mydata['Total']/3
mydata

# Visualisation en moyenne si  le gender a in impact sur la reussite a l'examen
ex_g<-ggplot(mydata, aes(x = Average, y = after_stat(density), color = gender)) +
  geom_density() +
  xlab("Score d'écriture") +
  ylab("Densité") +
  ggtitle("Moyenne par rapport en gender") +
  scale_color_manual(values = c("#E69F00", "#0072B2")) +
  theme_classic()
ex_g + theme(plot.title = element_text(hjust = 0.5))

#Visualisation en moyenne si le niveau des parents a impact sur la reussite 
ggplot(mydata, aes(x=Average, y=..density.., color=parental_level_of_education)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "Niveau d'éducation des parents") +
  ggtitle("Distribution de la moyenne en fonction du niveau d'éducation des parents") +
  theme_classic() +
  theme(legend.position="bottom")

#voir si le niveau des parents a un  impact sur la reussite des chez les hommes 
ggplot(mydata[mydata$gender == "male", ], aes(x=Average, y=..density.., color=parental_level_of_education)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "Niveau d'éducation des parents") +
  ggtitle("Distribution de la moyenne pour les hommes en fonction du niveau d'éducation des parents") +
  theme_classic() +
  theme(legend.position="bottom")
#voir si le niveau des parents a un  impact sur la reussite des chez les femmes
ggplot(mydata[mydata$gender == "female",], aes(x=Average, y=..density.., color=parental_level_of_education)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "Niveau d'éducation des parents") +
  ggtitle("Distribution de la moyenne pour les femmes en fonction du niveau d'éducation des parents") +
  theme_classic() +
  theme(legend.position="bottom")

#test de preparation en moyenne
ex_test_prepa<-ggplot(mydata, aes(x=Average, y=..density.., color=test_preparation_course)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "Test de preparation") +
  ggtitle("Distribution de la moyenne sur le test de preparation") +
  theme_classic() +
  theme(legend.position="bottom")
ex_test_prepa + theme(plot.title = element_text(hjust = 0.5))

#test de preparation en fonction du female
ex_test_female<-ggplot(mydata[mydata$gender == "female",], aes(x=Average, y=..density.., color=test_preparation_course)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = " Test de preparation en fonction des femmes" ) +
  ggtitle("Distribution de la moyenne chez  les femmes ") +
  theme_classic() +
  theme(legend.position="bottom")
ex_test_female + theme(plot.title = element_text(hjust = 0.5))

#test de preparation en fonction du male
ex_test_prepa_male<-ggplot(mydata[mydata$gender == "male",], aes(x=Average, y=..density.., color=test_preparation_course)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "test de preparation en fonction des hommes") +
  ggtitle("Distribution de la moyenne chez les hommes") +
  theme_classic() +
  theme(legend.position="bottom")
ex_test_prepa_male + theme(plot.title = element_text(hjust = 0.5))

#voir en moyenne si la nourriture a un impact sur la reussite de l'etudiant 
ex_lun<-ggplot(mydata, aes(x=Average, y=..density.., color=lunch)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "Le dejeune") +
  ggtitle("Distribution de la moyenne") +
  theme_classic() +
  theme(legend.position="bottom")
ex_lun + theme(plot.title = element_text(hjust = 0.5))

#Voir si le test de preparation a un impact sur la reussite chez les femmes 
ggplot(mydata[mydata$gender == "female",], aes(x=Average, y=..density.., color=lunch)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "Le dejeune") +
  ggtitle("Distribution de la moyenne pour les femmes en fonction du dejeune") +
  theme_classic() +
  theme(legend.position="bottom")

#Voir si la nourriture a un impact sur la reussite chez les hommes
ggplot(mydata[mydata$gender == "male",], aes(x=Average, y=..density.., color=lunch)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "Le dejeune") +
  ggtitle("Distribution de la moyenne pour les hommes en fonction du dejeune") +
  theme_classic() +
  theme(legend.position="bottom")

#Voir en moyenne si  race/ethinicity a un impact sur la reussité
ex_race_ethnicity<-ggplot(mydata, aes(x=Average, y=..density.., color=race_ethnicity)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "race ethnicity") +
  ggtitle("Distribution de la moyenne en fonction de race/ethnicity") +
  theme_classic() +
  theme(legend.position="bottom")
ex_race_ethnicity + theme(plot.title = element_text(hjust = 0.5))

#Voir  si  race/ethinicity a un impact sur la reussité chez les femmes
ex_race_ethnicity_female<-ggplot(mydata[mydata$gender == "female",], aes(x=Average, y=..density.., color=race_ethnicity)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "race ethnicity") +
  ggtitle("Distribution de la moyenne chez les femmes en fonction race/ethnicity") +
  theme_classic() +
  theme(legend.position="bottom")
ex_race_ethnicity_female + theme(plot.title = element_text(hjust = 0.5))

#Voir  si  race/ethinicity a un impact sur la reussité chez les hommes
ex_race_ethnicity_male<-ggplot(mydata[mydata$gender == "male",], aes(x=Average, y=..density.., color=race_ethnicity)) + 
  geom_density() +
  labs(x = "Moyenne", y = "Densité", color = "race ethnicity") +
  ggtitle("Distribution de la moyenne chez les Hommes en fonction du test de race ethnicity") +
  theme_classic() +
  theme(legend.position="bottom")
ex_race_ethnicity_male + theme(plot.title = element_text(hjust = 0.5))

